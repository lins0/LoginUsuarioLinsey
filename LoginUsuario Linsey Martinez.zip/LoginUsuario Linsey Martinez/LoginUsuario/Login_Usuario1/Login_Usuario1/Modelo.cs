﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login_Usuario1
{
    class Modelo
    {
        public int registro(Usuarios usuario)
        {
           
            MySqlConnection conexion = Conexion.getConexion();
            conexion.Open();
            string sql = "INSERT INTO usuarios (usuario, Contrasenia, nombre, id_tipo) VALUES(@usuario, @Contraseñia, @nombre, @id_tipoUsuario)";
            MySqlCommand comando = new MySqlCommand(sql, conexion);
            comando.Parameters.AddWithValue("@usuario", usuario.Usuario);
            comando.Parameters.AddWithValue("@Contrasenia", usuario.Contrasenia);
            comando.Parameters.AddWithValue("@nombre", usuario.Nombre);
            comando.Parameters.AddWithValue("@id_tipoUsuario", 1);

            int resultado = comando.ExecuteNonQuery();
            return resultado;
        }
        public bool existeusuario(string usuario)
        {
            MySqlDataReader reader;
            MySqlConnection conexion = Conexion.getConexion();
            conexion.Open();

            string sql = "SELECT id FROM usuarios WHERE usuario LIKE @usuario";
            MySqlCommand comando = new MySqlCommand(sql, conexion);
            comando.Parameters.AddWithValue("@usuario", usuario);
            reader = comando.ExecuteReader();
            if (reader.HasRows)
            {
                return true;
            }
            else
            { 
                return false;
            }

        }
    }
}

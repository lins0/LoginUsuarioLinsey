﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login_Usuario1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void RegistrarButton_Click(object sender, EventArgs e)
        {
            Usuarios usuarios = new Usuarios();
            usuarios.Usuario = UsuarioTextBox.Text;
            usuarios.Contrasenia = ContraseñaTextBox.Text;
            usuarios.ConPassword = ConfirmarContraTextBox.Text;
            usuarios.Nombre = RollNombreTextBox.Text;
            try
            {

                Controlador controlador = new Controlador();
                string respuesta = controlador.ctrlRegistro(usuarios);
                if (respuesta.Length > 0)
                {
                    MessageBox.Show(respuesta, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else
                {
                    MessageBox.Show("Usuario registrado", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);  
            }
        }
    } 
}

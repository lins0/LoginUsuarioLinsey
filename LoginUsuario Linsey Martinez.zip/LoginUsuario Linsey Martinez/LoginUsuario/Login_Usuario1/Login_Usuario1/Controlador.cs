﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Login_Usuario1
{
    class Controlador
    {
        public string ctrlRegistro(Usuarios usuarios)
        {
        Modelo modelo = new Modelo();
            string respuesta = "";

            if (string.IsNullOrEmpty(usuarios.Usuario) || string.IsNullOrEmpty(usuarios.Contrasenia) || string.IsNullOrEmpty
             (usuarios.ConPassword) || string.IsNullOrEmpty(usuarios.Nombre))
            {
                respuesta = "Debe llenar todos los campos";

            
            }else
            {
                if (usuarios.Contrasenia == usuarios.ConPassword)
                {
                   if (modelo.existeusuario(usuarios.Usuario))
                    {
                        respuesta = "El usuario ya existe";
                    }else
                    {
                        usuarios.Contrasenia = generarSHA1(usuarios.Contrasenia);
                        modelo.registro(usuarios);
                    }
                }else
                {
                        respuesta = "Las respuestas no coinciden";
                }

                
            }
            return respuesta;
        }
        private string generarSHA1(string cadena)
        {
            UTF8Encoding enc = new UTF8Encoding();
            byte[] data = enc.GetBytes(cadena);
            byte[] result;
          SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();
            result = sha.ComputeHash(data);

            StringBuilder sb = new StringBuilder();
            for (int i = 0;  i < result.Length; i++)
            {
                if (result[i] < 16)
                {
                    sb.Append("0");
                }
                sb.Append(result[i].ToString("x"));
            }
            return sb.ToString();
        
        }
    }
}
